// CS 172 - Assignment 3 - Tic-Tac-Toe
// Main File by Mark Boady
// Drexel University 2016

//You may add new methods (public or private) and new private attributes.
//You may NOT remove or change any methods given.

#ifndef _TIC_TAC_TOE_
#define _TIC_TAC_TOE_

#include <vector>
#include <iostream>
#include <string>
#include "symbol.h"
using namespace std;

class tBoard
{
	private:
		//The string that contains the tic tac toe board
		string table_;

		//The 2D vector that contains booleans determining whether spaces are empty or not
		vector<vector<bool>> spaces_taken_;
		//A vector that puts the state of the current space into the 2D vector spaces_taken_
		vector<bool> current_space_;

		//The 2D vector that contains the symbols that are in each spot on the board
		vector<vector<symbol>> character_spot_;
		//The vector that puts the current character into a specific spot in the 2D vector character_spot_
		vector<symbol> current_character_;

		//The boolean that determines if a player can move to a spot
		bool can_move_;

		//The symbol of the winner of the game
		symbol winner_;

		//The integer that keeps track fo the total moves made
		int moves_;

	public:
		//Default Constructor
		//Makes a board with all blank spaces
		tBoard();
		//Makes a move on the board
		//X is the row and y is the column
		//m is the symbol to place (either X or O)
		//It returns true if the move was made
		//If the move is illegal, return false and do not change the table
		bool move(symbol m, int x, int y);
		//Returns true if the game is over
		//This could be because of a winner or because of a tie
		bool game_over();
		//Returns who won X or O.
		//If the game was a tie, return  BLANK
		symbol winner();
		//Returns the current board
		const string get_table() const;
};
//Overload the output operator
ostream & operator<<(ostream& os, const tBoard& myTable);

#endif
