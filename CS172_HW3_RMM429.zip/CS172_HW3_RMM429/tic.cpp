#include "tic.h"

//Constants
const int BOARD_LENGTH = 3;
const int BOARD_WIDTH = 3;
const int ROW_1 = 2;
const int ROW_2 = 4;
const int ROW_3 = 6;
const int COL_1 = 4;
const int COL_2 = 10;
const int COL_3 = 16;
const int BOARD_CHAR_COUNT = 21;


//The default constructor
tBoard::tBoard()
{
	//Initalizing the board to be blank
	table_ = "";
	table_ += " |  0  |  1  |  2  |\n";
	table_ += " +-----------------+\n";
	table_ += "0|     |     |     |\n";
	table_ += " +-----------------+\n";
	table_ += "1|     |     |     |\n";
	table_ += " +-----------------+\n";
	table_ += "2|     |     |     |\n";
	table_ += " +-----------------+\n";

	//Initalizing all the board spaces to be open
	for (int i = 0; i < BOARD_LENGTH; i++)
	{
		for (int j = 0; j < BOARD_WIDTH; j++)
		{
			current_space_.push_back(true);
		}
		spaces_taken_.push_back(current_space_);
		current_space_.clear();
	}

	//Initalizing all the board characters to be blank
	for (int i = 0; i < BOARD_LENGTH; i++)
	{
		for (int j = 0; j < BOARD_WIDTH; j++)
		{
			current_character_.push_back(BLANK);
		}
		character_spot_.push_back(current_character_);
		current_character_.clear();
	}

	//Initalizing the "can move" boolean to be true
	can_move_ = true;

	//Initalizing the number of moves made to be zero
	moves_ = 0;

}

//Checking to see if a character can be placed in a certain spot, then placing the character there if able to
bool tBoard::move(symbol m, int y, int x)
{
	if (spaces_taken_[x][y] == true)
	{
		can_move_ = true; //The user can move there

		spaces_taken_[x][y] = false; //Now the space is taken on the board
		moves_++; //Increasing total number of moves

		//Placing the character in the specified spot if the character is X
		if (m == X)
		{
			switch (x)
			{
			case 0:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_1] = 'X';
					character_spot_[x][y] = X;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_1] = 'X';
					character_spot_[x][y] = X;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_1] = 'X';
					character_spot_[x][y] = X;
					break;
				}
				break;
			case 1:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_2] = 'X';
					character_spot_[x][y] = X;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_2] = 'X';
					character_spot_[x][y] = X;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_2] = 'X';
					character_spot_[x][y] = X;
					break;
				}
				break;
			case 2:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_3] = 'X';
					character_spot_[x][y] = X;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_3] = 'X';
					character_spot_[x][y] = X;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_3] = 'X';
					character_spot_[x][y] = X;
					break;
				}
				break;
			}
		}
		//Placing the character in the specified spot if the character is O
		else
		{
			switch (x)
			{
			case 0:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_1] = 'O';
					character_spot_[x][y] = O;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_1] = 'O';
					character_spot_[x][y] = O;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_1] = 'O';
					character_spot_[x][y] = O;
					break;
				}
				break;
			case 1:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_2] = 'O';
					character_spot_[x][y] = O;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_2] = 'O';
					character_spot_[x][y] = O;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_2] = 'O';
					character_spot_[x][y] = O;
					break;
				}
				break;
			case 2:
				switch (y)
				{
				case 0:
					table_[(BOARD_CHAR_COUNT * ROW_1) + COL_3] = 'O';
					character_spot_[x][y] = O;
					break;
				case 1:
					table_[(BOARD_CHAR_COUNT * ROW_2) + COL_3] = 'O';
					character_spot_[x][y] = O;
					break;
				case 2:
					table_[(BOARD_CHAR_COUNT * ROW_3) + COL_3] = 'O';
					character_spot_[x][y] = O;
					break;
				}
				break;
			}
		}
	}
	//If the spot is taken, let the player know they cannot move there
	else
	{
		can_move_ = false;
	}

	//Returning the "can move" boolean
	return can_move_;
}

//Checking to see if the game is over and determining the potential winner
bool tBoard::game_over()
{
	//Checking the eight possible ways to win tic tac toe and determining which character it was that won

	if (character_spot_[0][0] == X && character_spot_[1][0] == X && character_spot_[2][0] == X) //These types of conditions make sure that if three sequential winning spots are filled, that they are all of the same character so an appropriate winner is determined
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][0] == O && character_spot_[1][0] == O && character_spot_[2][0] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[0][1] == X && character_spot_[1][1] == X && character_spot_[2][1] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][1] == O && character_spot_[1][1] == O && character_spot_[2][1] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[0][2] == X && character_spot_[1][2] == X && character_spot_[2][2] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][2] == O && character_spot_[1][2] == O && character_spot_[2][2] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[0][0] == X && character_spot_[0][1] == X && character_spot_[0][2] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][0] == O && character_spot_[0][1] == O && character_spot_[0][2] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[1][0] == X && character_spot_[1][1] == X && character_spot_[1][2] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[1][0] == O && character_spot_[1][1] == O && character_spot_[1][2] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[2][0] == X && character_spot_[2][1] == X && character_spot_[2][2] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[2][0] == O && character_spot_[2][1] == O && character_spot_[2][2] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[0][0] == X && character_spot_[1][1] == X && character_spot_[2][2] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][0] == O && character_spot_[1][1] == O && character_spot_[2][2] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	if (character_spot_[0][2] == X && character_spot_[1][1] == X && character_spot_[2][0] == X)
	{
		winner_ = X;
		return true;
	}
	else if (character_spot_[0][2] == O && character_spot_[1][1] == O && character_spot_[2][0] == O)
	{
		winner_ = O;
		return true;
	}
	else
	{
	}

	//Determining a tie if no win conditions were met and all nine possible moves were made
	if (moves_ == 9)
	{
		winner_ = BLANK;
		return true;
	}

	//Continuing the game if no conditions were met
	return false;

}

//Returning who the winner is
symbol tBoard::winner()
{
	return winner_;
}

//A method that print out the current state of the board
const string tBoard::get_table() const
{
	return table_;
}

//Overloading the output operator to print out the current state of the board
ostream & operator<<(ostream& os, const tBoard& myTable)
{
	os << myTable.get_table();
	return os;
}