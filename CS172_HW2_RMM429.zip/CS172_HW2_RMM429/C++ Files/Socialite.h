/*
Program: Socialite.h
Purpose: To create method prototypes and private variables whose definitions are defined in the "Socialite.cpp" file.
Author: Ricky Mangerie
Last Date Revised: 4/28/2016
Contact: rmm429@drexel.edu
*/
//Header definition
#ifndef _SOCIALITE_
#define _SOCIALITE_

//Preprocessor
#include <iostream>
#include <string>
#include <vector> //Accessing all vector properties
using namespace std;

//Defining the Socialite class
class Socialite
{
	//Private attributes to the Socialite class, not directly accessable by users
	private:

		//Attributes
		string last_name_;
		string first_name_;
		string user_id_;
		string picture_;
		string website_;
		string description_;
		vector<string> cliques_;
		int clique_no_;

	//Public methods of the Socialite class, directly accessable by users
	public:

		//Constructor
		Socialite();

		//Mutators
		void setLastName(string &ln);
		/*
			Sets the last name of the user

			@param ln - a reference parameter that contains the user's last name

			NOTES: Must only enter the last name, no first name needed

			PROGRAMMER: Ricky Mangerie
		*/

		void setFirstName(string &fn);
		/*
			Sets the first name of the user

			@param fn - a reference parameter that contains the user's first name

			NOTES: Must only enter the first name, no last name needed

			PROGRAMMER: Ricky Mangerie
		*/

		void setUserID(string &id);
		/*
			Sets the id of the user

			@param id - a reference parameter that contains the user's id

			NOTES: ID can contain any characters except for the space character and can be of any length

			PROGRAMMER: Ricky Mangerie
		*/

		void setPicture(string &p);
		/*
			Sets the user's profile picture

			@param p - a reference parameter that contains the URL of the user's profile picture

			NOTES: Must enter a valid image URL.

			PROGRAMMER: Ricky Mangerie
		*/

		void setWebsite(string &u);
		/*
			Sets the user's shared webiste

			@param u - a reference parameter that contains the URL of the user's shared website

			NOTES: Must enter a valid URL.

			PROGRAMMER: Ricky Mangerie
		*/

		void setDescription(string &d);
		/*
			Sets the description of the user's shared webiste

			@param d - a reference parameter that contains the description of the user's shared website

			NOTES: Any description is valid.

			PROGRAMMER: Ricky Mangerie
		*/

		void setNextClique(string &c);
		/*
			Sets the next Clique that the user is a member of

			@param c - a reference parameter that contains the name of the Clique that the user joined
	
			NOTES: Any description is valid.

			PROGRAMMER: Ricky Mangerie
		*/

		//Accessors
		string getLastName();
		/*
			Returns the last name of the user

			@return last_name_ - a string that contains the user's last name

			PROGRAMMER: Ricky Mangerie
		*/

		string getFirstName();
		/*
			Returns the first name of the user

			@return first_name_ - a string that contains the user's first name

			PROGRAMMER: Ricky Mangerie
		*/

		string getUserID();
		/*
			Returns the id of the user

			@return user_id_ - a string that contains the user's id

			PROGRAMMER: Ricky Mangerie
		*/

		string getPicture();
		/*
			Returns the user's profile picture URL

			@return picture_ - a string that contains the URL of the user's profile picture

			NOTES: This method will return the URL of the picture, not the acutal picture

			PROGRAMMER: Ricky Mangerie
		*/

		string getWebsite();
		/*
			Returns the URL of the user's shared webiste

			@return website_ - a string that contains the URL of the user's shared website

			NOTES: This method will return the URL of the website, not the actual website

			PROGRAMMER: Ricky Mangerie
		*/

		string getDescription();
		/*
			Returns the description of the user's shared webiste

			@return  - a string that contains the description of the user's shared website

			PROGRAMMER: Ricky Mangerie
		*/

		string getCliques();
		/*
			Returns all Cliques that the user is a member of

			@return  - the names of all the Cliques that the user is a member of

			PROGRAMMER: Ricky Mangerie
		*/

		string getCliquesHTML();
		/*
			Returns all Cliques that the user is a member of in an HTML list

			@return  - the names of all the Cliques that the user is a member of formatted for HTML output

			PROGRAMMER: Ricky Mangerie
		*/

		int getCliqueNo();
		/*
			Returns the number of Cliques a user is a member of

			@return  - an integer that represents how many Cliques the user is a member of

			PROGRAMMER: Ricky Mangerie
		*/


		string getSpecificClique(int i);
		/*
			Returns a specific Clique under the user's specification

			@param i - a reference parameter that contains the speicifc Clique index that the user wants to retrieve in the vector of Cliques

			@return  - the name of the Clique that the user requested

			NOTES: The parameter i must be a positive integer within the range of possible Cliques available

			PROGRAMMER: Ricky Mangerie
		*/

		//Facilitators
		void outputText(ostream &os);
		/*
			Outputs the inputted information with text formatting

			@param os - a reference parameter that contains an object of the output stream

			NOTES: The reference parameter os can either be console output or output to a text file

			PROGRAMMER: Ricky Mangerie
		*/

		void outputHTML(ostream &os);
		/*
			Outputs the inputted information with html formatting

			@param os - a reference parameter that contains an object of the output stream

			NOTES: The reference parameter os can either be console output or output to an html file

			PROGRAMMER: Ricky Mangerie
		*/

		void clearCliques();
		/*
			Clears the contents of the Cliques vector

			PROGRAMMER: Ricky Mangerie
		*/
};

//End of header
#endif