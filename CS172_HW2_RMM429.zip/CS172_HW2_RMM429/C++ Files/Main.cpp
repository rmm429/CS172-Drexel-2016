/*
Program: Main.cpp
Purpose: To create multiple text and HTML Socialite pages based on data from a text file
Author: Ricky Mangerie
Last Date Revised: 4/28/2016
Contact: rmm429@drexel.edu
*/

//Preprocessor
#include "Socialite.h"; //Importing properties from the header file
#include <iostream>
#include <string>
#include <fstream> //Allows for the use of the stream class
using namespace std;

int main()
{
	//Text and HTML output file objects
	ofstream text;
	ofstream web;

	//Data input file object
	ifstream data;

	//Local variables
	string first_name;
	string last_name;
	string user_id;
	string picture;
	string website;
	string description;
	string file_name_txt;
	string file_name_html;
	string current_Clique;
	int Clique_index;

	//Object of the Socialite class, calls the constructor
	Socialite Profile = Socialite();

	//Opening the input file
	data.open("input.txt");

	//Reading data from the file until the file has no more data to be read
	while (!data.eof())
	{
		//Getting the specific user ID from the text file
		getline(data, user_id, '\n');
		Profile.setUserID(user_id);

		//Getting the specific first name from the text file
		getline(data, first_name, '\n');
		Profile.setFirstName(first_name);

		//Getting the specific last name from the text file
		getline(data, last_name, '\n');
		Profile.setLastName(last_name);

		//Getting the specific profile picture URL from the text file
		getline(data, picture, '\n');
		Profile.setPicture(picture);

		//Getting the specific shared website URL from the text file
		getline(data, website, '\n');
		Profile.setWebsite(website);

		//Getting the specific shared website description from the text file
		getline(data, description, '\n');
		Profile.setDescription(description);

		current_Clique = ""; //Resetting the Clique string so that the while loop works properly
		
		//Whenever the current line is four plus symbols, there are no more Cliques to be read
		while (current_Clique != "++++")
		{
			//Retrieving the current Clique
			getline(data, current_Clique, '\n');

			//Making sure that the four plus symbols are not set as a Clique
			if (current_Clique != "++++")
			{
				//Adding the current Clique to the Clique vector
				Profile.setNextClique(current_Clique);
			}
			else
			{
				//Do nothing if the Clique string equals four plus symbols
			}
		}

		//Creating the names of the files from the User ID and creating the file objects
		file_name_txt = user_id + ".txt";
		text.open(file_name_txt);
		file_name_html = user_id + ".html";
		web.open(file_name_html);

		//Calling the functions that output the supplied information to the console
		cout << "\n";
		Profile.outputText(cout);
		cout << "\n";
		Profile.outputHTML(cout);

		//Calling the functions that output the supplied information to a text file and HTML file
		Profile.outputText(text);
		Profile.outputHTML(web);

		//Closing the files
		text.close();
		web.close();

		//Clearing the contents of the Cliques vector
		Profile.clearCliques();
	}

	//Closing the input file
	data.close();

	//Error check value
	return 0;
}