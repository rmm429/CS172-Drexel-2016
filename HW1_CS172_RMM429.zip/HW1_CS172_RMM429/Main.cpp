/*
Program: Main.cpp
Purpose: To create a text file and html file based on user-inputted information
Author: Ricky Mangerie
Last Date Revised: 4/14/2016
Contact: rmm429@drexel.edu
*/

//Preprocessor
#include "Socialite.h"; //Importing properties from the header file
#include <iostream>
#include <string>
#include <fstream> //Allows for the use of the stream class
using namespace std;

int main()
{
	//Text and HTML output file objects
	ofstream text;
	ofstream web;

	//Local variables
	string first_name;
	string last_name;
	string user_id;
	string picture;
	string website;
	string description;
	string file_name_txt;
	string file_name_html;

	//Object of the Socialite class, calls the constructor
	Socialite Profile = Socialite();

	//Getting information from the user and sending it to the Socialite class through an object of the class
	cout << "What is your first name: ";
	cin >> first_name;
	Profile.setFirstName(first_name);

	cout << "What is your last name: ";
	cin >> last_name;
	Profile.setLastName(last_name);

	cout << "What User ID would you like: ";
	cin >> user_id;
	Profile.setUserID(user_id);

	cout << "Please include the URL of your profile picture: ";
	cin >> picture;
	Profile.setPicture(picture);

	cout << "What website would you like to share: ";
	cin >> website;
	Profile.setWebsite(website);

	cout << "Please include a description of your shared website: ";
	cin.ignore(); //Ensuring that getline works
	getline(cin, description, '\n'); //Obtaining multi-space text from the user
	Profile.setDescription(description);

	//Creating the names of the files from the User ID and creating the file objects
	file_name_txt = user_id + ".txt";
	text.open(file_name_txt);
	file_name_html = user_id + ".html";
	web.open(file_name_html);

	//Calling the functions that output the supplied information to the console
	cout << "\n";
	Profile.outputText(cout);
	cout << "\n";
	Profile.outputHTML(cout);

	//Calling the functions that output the supplied information to a text file and HTML file
	Profile.outputText(text);
	Profile.outputHTML(web);

	//Closing the files
	text.close();
	web.close();

	//Error check value
	return 0;
}