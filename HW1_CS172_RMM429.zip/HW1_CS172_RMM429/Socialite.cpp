/*
Program: Socialite.cpp
Purpose: To create method definitions whose prototypes are defined in the "Socialite.h" file.
Author: Ricky Mangerie
Last Date Revised: 4/14/2016
Contact: rmm429@drexel.edu
*/
//Preprocessor
#include "Socialite.h" //Importing properties from the header file
#include <string>
#include <iostream>
using namespace std;

//Constants used for HTML formatting
const string H1_FONT = "Times New Roman";
const string H2_FONT = "Verdana";
const string PICTURE_ALIGN = "LEFT";
const string H1_ALIGN = "CENTER";
const string H2_ALIGN = "CENTER";
const string FONT_COLOR = "BLUE";
const string BG_COLOR = "RED";
const string BREAK = "<br />";
const string BAR = "<hr / >";

//Constructor definition
Socialite::Socialite()
{
	last_name_ = "";
	first_name_ = "";
	user_id_ = "";
	picture_ = "";
	website_ = "";
	description_ = "";
};

//Mutator definitions
void Socialite::setLastName(string &ln)
{
	last_name_ = ln;
}
void Socialite::setFirstName(string &fn)
{
	first_name_ = fn;
}
void Socialite::setUserID(string &id)
{
	user_id_ = id;
}
void Socialite::setPicture(string &p)
{
	picture_ = p;
}
void Socialite::setWebsite(string &w)
{
	website_ = w;
}
void Socialite::setDescription(string &d)
{
	description_ = d;
}

//Accessor definitions
string Socialite::getLastName()
{
	return last_name_;
}
string Socialite::getFirstName()
{
	return first_name_;
}
string Socialite::getUserID()
{
	return user_id_;
}
string Socialite::getPicture()
{
	return picture_;
}
string Socialite::getWebsite()
{
	return website_;
}
string Socialite::getDescription()
{
	return description_;
}

//Facilitator definitions
void Socialite::outputText(ostream &os)
{
	//Outputting the supplied information to a text document or console with formatting
	os << "First Name: " << getFirstName() << "\n";
	os << "Last Name: " << getLastName() << "\n";
	os << "User ID: " << getUserID() << "\n";
	os << "Picture: " << getPicture() << "\n";
	os << "Website: " << getWebsite() << "\n";
	os << "Website Description: " << getDescription() << "\n";
}
void Socialite::outputHTML(ostream &os)
{
	//Outputting the supplied information to an HTML document or console with HTML formatting
	os << "<html>" << "\n";
	os << "<head>" << "\n";
	os << "<title>" << getFirstName() << " " << getLastName() << "'s Socialite Page" << "</title>" << "\n";
	os << "</head>" << "\n\n";

	os << "<body bgcolor=\"" << BG_COLOR << "\">" << "\n";
	os << "<img SRC=\"" << getPicture() << "\" ALIGN=\"" << PICTURE_ALIGN << "\" />" << "\n";
	os << "<h1 ALIGN=\"" << H1_ALIGN << "\"><font face=\"" << H1_FONT << "\">" << getFirstName() << " " << getLastName() << "</font></h1>" << "\n";
	os << "<h2 ALIGN=\"" << H2_ALIGN << "\"><font face=\"" << H2_FONT << "\">" << getUserID() << "</font></h2>" << "\n";
	os << BAR << "\n";
	os << "<p>" << getFirstName() << " wants to share " << "<a HREF=\"" << getWebsite() << "\" TARGET=_blank>" << getDescription() << "</a> with you:" << "\n";
	os << BREAK << "\n";
	os << "<font color=\"" << FONT_COLOR << "\">" << getWebsite() << "</font>" << "\n";
	os << "</body>" << "\n\n";

	os << "</html>";
}

